# 说明
* 把[此压缩包](https://github.com/Bush2021/chrome_plus/blob/main/setdll/setdll.7z)内的所有文件解压到要注入的浏览器的运行程序所在目录，运行 injectpe.bat；当命令行运行成功后，会自动删除多余的文件。

* 此程序基于 Microsoft Edge 设置，如果使用想使用在其它浏览器上请自行修改 injectpe.bat 中 msedge.exe 字段为想要注入的浏览器的可执行程序。

* 代码来自：https://github.com/adonais/setdll/

# Instruction
* Extract all the files in [the zip file](https://github.com/Bush2021/chrome_plus/blob/main/setdll/setdll.7z) to the directory of the browser running program to be injected. Run injectpe.bat; After the CLI is successfully run, redundant files are automatically deleted.

* This program is based on Microsoft Edge Settings. If you want to use it in other browsers, change the msedge.exe field in injectpe.bat to the executable program of the browser you want to inject.

* Code from this project: https://github.com/adonais/setdll/
